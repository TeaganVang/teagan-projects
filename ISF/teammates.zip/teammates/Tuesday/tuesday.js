document.body.innerHTML = "This is the ultimate state of human emotion. More passionate than Hope. Far deeper than Despair. It is Love.";
//Javascript is case sensitive
var a = 10;
var b = 35;
var sum = a + b;

console.log(sum)