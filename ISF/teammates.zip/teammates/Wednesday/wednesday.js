
//Variebles

//var, let, const

//Data Type String

//var a;

//var b = "Teagan is sad"; //string is a  wrapped in quotes ('' or "")
//console.log(b);

//var b = "This is a string";

//console.log(b);

//Data Type Number/Numeric

//var num = 1234;

//var nums = "1234";

//console.log(nums)

//var num = 50;
//console.log(num);

//var name = 'It is a good "bad" day';

//Data Type Boolean True/False

//var bool = true;
//var bbol1 = false;
//var bool2 = 1;
//var bool3 = 0;

//Data Type Undefined

//var a;

//console.log(a)

//Data Type Null

//var gold = null;

//console.log(gold)

//5 Data Types

//Typeof (a property to use to say hey idk)

//console.log(typeof bool)

//Assignment Operators
/*
=
+=
-=
/=
%=
*/

//var num = 34;

//number = number + 5

//number %=5;

//console.log(number);

//Arithmatic Operators

/*
+
-
/
%
*/

//console.log(5 + 5);

//var age = 21;

//var names = "Teagan is" + age + "years old";

//console.log(names);

//MY TICKET TO LEAVE 
var a = 10;
var b = 20;
var c = 30;
var d = 40;
var e = 50;

var num = "a" + "b" + "c" + "d" + "e";

console.log(num)


